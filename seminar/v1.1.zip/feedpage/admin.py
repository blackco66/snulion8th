from django.contrib import admin
from .models import Feed

admin.site.register(Feed)
# Register your models here.
